#include <stdio.h>

void win() {
    FILE * f;
    char buff[255];
    f = fopen("flag.txt", "r");
    if (f) {
        fscanf(f, "%s", buff);
        printf("%s\n",buff);
    }
}

int main() {
    char s[36];
    printf("Enter string: ");
    gets(s);
    printf("This is flag{dont_trust_me}\n");
    return 0;
}